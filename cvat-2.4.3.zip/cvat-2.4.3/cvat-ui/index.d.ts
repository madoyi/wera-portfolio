// Copyright (C) 2020-2022 Intel Corporation
// Copyright (C) 2022-2023 CVAT.ai Corporation
//
// SPDX-License-Identifier: MIT

import 'redux-thunk/extend-redux';

declare module '*.svg';
declare module 'cvat-core/src/api';
