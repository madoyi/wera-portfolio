// Copyright (C) 2022 CVAT.ai Corporation
//
// SPDX-License-Identifier: MIT

declare module '*.svg';
